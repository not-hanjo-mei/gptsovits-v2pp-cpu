// ORT-free static-plan inference engine (see ORT-FREE.md for the design).
//
// A graph is compiled once into a Plan: a fixed sequence of kernel steps
// over values whose shapes are affine expressions of a few runtime dim
// symbols (for the GPT stage graph: just the sequence length). Each call
// binds concrete input tensors, resolves shapes numerically, assigns a
// static arena by value lifetime, and runs the steps with no per-op
// dispatch beyond a switch. Layout ops are views (offset + strides), not
// copies. PackedMatMul steps call the existing packed::gemm_* kernels
// through a caller-supplied weight lookup, so this engine consumes the
// same weight packs and BlobStore as the ORT host. The baked (fp32)
// form of a graph compiles through the identical path: its linear steps
// bind fp32 constant tensors instead of packed ones.
#pragma once
#include <cstdint>
#include <functional>
#include <map>
#include <memory>
#include <string>
#include <vector>

#include "onnx_model.h"

namespace freeeng {

// Tensor view exchanged with the caller. Strides are in elements; an
// empty strides vector means contiguous row-major.
struct Tensor {
    int dtype = 0;  // ONNX elem type (1 f32, 2 u8, 6 i32, 7 i64, 9 bool)
    const uint8_t* data = nullptr;
    std::vector<int64_t> shape;
    std::vector<int64_t> strides;
    int64_t numel() const {
        int64_t n = 1;
        for (auto d : shape) n *= d;
        return n;
    }
    bool contiguous() const { return strides.empty(); }
};

// Resolved packed weight for one PackedMatMul node base name.
struct PackedBinding {
    const uint8_t* pk = nullptr;
    const float* sc = nullptr;
    const uint8_t* ze = nullptr;  // null for W8 modes
};
// Given the graph tensor base name (PackedMatMul input names carry
// __pk/__sc/__ze suffixes; the base is what remains after stripping),
// fill the binding. Return false if the name is unknown.
using PackedLookup = std::function<bool(const std::string& base, PackedBinding& out)>;

// Shared KV cache state for stateful stage plans (see
// Plan::set_kv_cache). Opaque; defined in free_engine.cpp.
struct KvCache;
std::shared_ptr<KvCache> make_kv_cache();

class Plan {
  public:
    // Compile from a parsed graph. Throws std::runtime_error on any op
    // or pattern outside the implemented set (the census set).
    // fp16_weights: store MatMul/Gemm weight operands (graph
    // initializers) as fp16 and convert on the fly at run time (M2
    // fp16 weight storage; halves weight traffic, compute stays
    // fp32). Only where the CPU reports AVX2+FMA+F16C; other CPUs
    // keep the fp32 originals. Off by default: callers opt in per
    // plan (the GPT plans; never the vits plan, whose gate is an
    // exact fp32 comparison).
    static std::shared_ptr<Plan> compile(const onnxm::Graph& g, std::string label,
                                         bool fp16_weights = false);
    void set_packed_lookup(PackedLookup fn) { lookup_ = std::move(fn); }
    // Attach a shared KV cache. Plans compiled from a graph with
    // feedback pairs (Concat(graph_input, new_slice) -> graph
    // output, axis 0 -- the GPT stage graphs' past/present) keep
    // those tensors in the cache's padded buffers instead of
    // re-copying the whole history every step: bind views the
    // buffer at the current length, the concat step appends only
    // the new slice. Two plans sharing one cache stay in sync
    // (the stage ping-pong). The caller supplies the past tensors
    // on the first run (copied in), then passes them as missing.
    // A fresh cache per request resets the state. Plans without a
    // cache attached behave exactly as before.
    void set_kv_cache(std::shared_ptr<KvCache> c) { kv_cache_ = std::move(c); }

    struct Instance;
    // Bind inputs (name -> tensor) and run. Outputs reference instance
    // storage and stay valid until the next run on the same Plan (the
    // caller copies what must persist, exactly like the tf_check state
    // hand-off). Throws on missing inputs or shape errors.
    std::map<std::string, Tensor> run(const std::map<std::string, Tensor>& inputs);
    // Indexed form: inputs in input_names() order (an entry with
    // data == nullptr counts as missing, same rule as the map
    // form), outputs returned in output_names() order. The host's
    // decode loop uses this to avoid rebuilding name maps and
    // renamed key strings on every step.
    std::vector<Tensor> run_vec(const std::vector<Tensor>& inputs);
    // Drop the run arenas (work + outputs). The next run re-plans and
    // regrows them. Callers must have copied out anything they keep:
    // outputs point into these arenas. Used by the host for plans whose
    // peak is large but whose lifetime is one phase of a request (GPT
    // encoder/first, vits), so steady RSS tracks concurrently-live
    // memory instead of the sum of per-phase peaks.
    void release_arena();
    const std::vector<std::string>& input_names() const { return in_names_; }
    const std::vector<std::string>& output_names() const { return out_names_; }
    size_t arena_bytes() const { return arena_bytes_; }
    size_t step_count() const { return n_steps_; }

  private:
    PackedLookup lookup_;
    std::shared_ptr<KvCache> kv_cache_;
    std::vector<std::string> in_names_, out_names_;
    size_t arena_bytes_ = 0;
    size_t n_steps_ = 0;
    std::shared_ptr<void> impl_;  // free_engine.cpp's internal Impl
};

}  // namespace freeeng
